package com.hayukleung.appwidget.clock;

/**
 * chargerlink_v2
 * com.hayukleung.bequiet.ui.widget.clock
 * ClockConfiguration.java
 *
 * by hayukleung
 * at 2016-08-26 15:04
 */
public class ClockConfiguration {
}
