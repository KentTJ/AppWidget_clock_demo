package com.hayukleung.appwidget;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.hayukleung.appwidget.clock.ClockService;

/**
 * AppWidget
 * com.hayukleung.appwidget
 * NullActivity.java
 *
 * by hayukleung
 * at 2017-03-16 18:38
 */

public class NullActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        Log.i("chen_", "NullActivity, onCreate: ");
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(new Intent(this, ClockService.class)); // 高版本的安卓，必须是前台服务才可以（所以，这里利用前台activity启动）
        }else{
//            getContext().startService(new Intent(mContext, AreaService.class));
        }
    }
}
