# AppWidget
Demo for Android App Widget.

## clock
![clock](./img/app-widget-clock.gif)
<br/>
[对应的简书博文](http://www.jianshu.com/p/2e75b695459a)
